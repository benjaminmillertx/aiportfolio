<script lang="ts">
    import Header from '$lib/components/Header.svelte';
    import Modal from '$lib/components/Modal.svelte';
	import PopUpCard from '$lib/components/PopUpCard.svelte';
    import { cardState } from '$lib/store/GlobalState';
import '../app.css';
	let { children } = $props();
</script>


<Header/>


<Modal/>

{@render children()}

<PopUpCard x={$cardState.position.x} y={$cardState.position.y + 250} isHovered={$cardState.isHovered}/>