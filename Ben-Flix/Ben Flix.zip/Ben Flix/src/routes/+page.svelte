<script lang="ts">
    import Carousel from "$lib/components/Carousel.svelte";
import Header from "$lib/components/Header.svelte";
    import HeroSection from "$lib/components/HeroSection.svelte";
    import { popularMovies, selectedMovie } from "$lib/store/GlobalState";


    export let data :{
        popularMovies: Movie[],
        selectedMovie:MovieDetails
        moviesByGenres:MoviesWithGenre[]
        topRatedMovies: Movie[],
        trendingMovies: Movie[],
    }

    console.log(data);
    

    $: popularMovies.set(data.popularMovies)
    $: selectedMovie.set(data.selectedMovie)


    
</script>

<div class="relative text-white">
    <HeroSection/>


    <div class="absolute w-full top-[35vh] md:top-[65vh] lg:top-[85vh] pl-10 flex flex-col space-y-4">
        <Carousel title="Popular Movies" items={data.popularMovies}/>
        <Carousel title="Trending Movies" items={data.trendingMovies}/>
        <Carousel title="Top-Rated Movies" items={data.topRatedMovies}/>

        {#each data.moviesByGenres as moviesList }
        <Carousel title={moviesList.name} items={moviesList.movies}/>
            
        {/each}
    </div>
</div>