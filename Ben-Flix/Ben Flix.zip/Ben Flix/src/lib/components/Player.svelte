<script lang="ts">
    import Plyr from "plyr";
    import "plyr/dist/plyr.css";
    import { createEventDispatcher, onDestroy, onMount } from "svelte";

    export let videoId: string = "LNlrGhBpYjc";

    let player : Plyr;
    let playerElement :any;
    export let isMuted: boolean = true;
    export let showControls: boolean = false;

    const dispatch = createEventDispatcher()


    export const toggleMute =()=>{
        if(player){
            if(player.muted) {
                player.muted = false;
                isMuted = false;
                dispatch("unmute");
            }else{
                player.muted = true;
                isMuted = true;
                dispatch("mute");
            }
        }
    }


    onMount(() => {
        if (typeof window !== "undefined") {
            player = new Plyr(playerElement, {
                autopause: false,
                disableContextMenu: true,
                muted: isMuted,
                controls: showControls
                    ? [
                          "play-large", // The large play button in the center
                          "restart", // Restart playback
                          "rewind", // Rewind by the seek time (default 10 seconds)
                          "play", // Play/pause playback
                          "fast-forward", // Fast forward by the seek time (default 10 seconds)
                          "progress", // The progress bar and scrubber for playback and buffering
                          "current-time", // The current time of playback
                          "duration", // The full duration of the media
                          "mute", // Toggle mute
                          "volume", // Volume control
                          "captions", // Toggle captions
                          "settings", // Settings menu
                          "pip", // Picture-in-picture (currently Safari only)
                          "airplay", // Airplay (currently Safari only)
                          "download", // Show a download button with a link to either the current source or a custom URL you specify in your options
                          "fullscreen", // Toggle fullscreen
                      ]
                    : [],

                    youtube:{
                        modestBranding:1,
                        rel:0,
                        iv_load_policy:3
                    }
            });

            player.on("ready", () => {
                console.log("Player is ready");

                setTimeout(()=>{
                        player.play();
                        console.log("playing");
                        
                },500)
            });

            player.on("mute",()=>{
                isMuted =true
                dispatch("mute")
            })
            player.on("unmute",()=>{
                isMuted =false
                dispatch("unmute")
            })
        }
    });


   onDestroy(()=>{
    if(player){
        console.log("destroy");
        
        player.destroy()
    }
   })
</script>

<div
    class={`${showControls ? "h-[100vh] flex justify-center items-center" : "h-full"} relative bg-black overflow-hidden shadow-lg`}
>
    <div
        class={`flex justify-center aspect-video ${showControls ? "h-[100vh] w-[90%]" : "scale-[1.4]"}`}
    >
        <div
            bind:this={playerElement}
            data-plyr-provider="youtube"
            data-plyr-embed-id={videoId}
        ></div>
    </div>
</div>

<style>
    /* src/lib/PlyrCustom.css */

    /* Custom Plyr variables to style the player */
    :root {
        --plyr-color-main: #ff000078;
        --plyr-video-background: rgba(0, 0, 0, 1);
        --plyr-focus-visible-color: #00b3ff;
        --plyr-badge-background: #4a5464;
        --plyr-badge-text-color: #ffffff;
        --plyr-captions-background: rgba(0, 0, 0, 0.8);
        --plyr-captions-text-color: #ffffff;
        --plyr-control-icon-size: 24px;
        --plyr-control-spacing: 12px;
        --plyr-control-radius: 6px;
        --plyr-control-toggle-checked-background: #ff0000;
        --plyr-video-controls-background: linear-gradient(
            rgba(0, 0, 0, 0),
            rgba(0, 0, 0, 0.85)
        );
        --plyr-video-control-color: #6d6d6d;
        --plyr-video-control-color-hover: #ff0000;
        --plyr-video-control-background-hover: #ffffff;
        --plyr-menu-background: rgba(255, 255, 255, 0.9);
        --plyr-menu-color: #000000;
        --plyr-tooltip-background: rgba(255, 255, 255, 0.9);
        --plyr-tooltip-color: #000000;
        --plyr-font-family: "Arial", sans-serif;
        --plyr-font-size-base: 16px;
        --plyr-font-weight-bold: 600;
    }

    .plyr--video {
        height: 20px !important;
    }
    /* Optional: Customize loading spinner */
    .plyr__spinner {
        border-top-color: var(--plyr-color-main);
    }

    /* Optional: Customize progress bar */
    .plyr__progress__filled {
        background-color: var(--plyr-color-main);
    }

    /* Optional: Customize menu items */
    .plyr__menu__container {
        background-color: var(--plyr-menu-background);
    }
    .plyr__menu__item {
        color: var(--plyr-menu-color);
    }

    /* Custom Mute Button Styles */
    .mute-button {
        /* Adjust the size and positioning as needed */
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background-color 0.3s ease;
        cursor: pointer;
    }

    .mute-button:hover {
        background-color: rgba(0, 0, 0, 0.7);
    }

    /* Optional: Add cursor pointer */
    .mute-button {
        cursor: pointer;
    }
</style>
