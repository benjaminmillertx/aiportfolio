<script lang="ts">
    import { ChevronLeft, ChevronRight } from "lucide-svelte";
    import Card from "./Card.svelte";

    export let title: string = ""

    export let items : Movie[] = []

    const scrollAmount : number = 320


    let carouselContainer : HTMLDivElement | null = null
    let scrollPosition : number = 0 


    const scrollLeft = ()=>{
        if(carouselContainer){
            scrollPosition = Math.max(0,scrollPosition - scrollAmount)
            carouselContainer.scrollTo({
                left:scrollPosition ,
                behavior: "smooth"
            })
        }
    }

    const scrollRight = ()=>{
        if(carouselContainer){
            scrollPosition += scrollAmount
            carouselContainer.scrollTo({
                left:scrollPosition ,
                behavior: "smooth"
            })
        }
    }


    const handleScroll = ()=>{
        if(carouselContainer){
            scrollPosition = carouselContainer.scrollLeft
    }}
</script>

<div class="carousel-wrapper">
    <h1 class="mt-4 mb-2 text-white text-2xl font-semibold">{title}</h1>

    <div class="carousel-container-wrapper relative">

        {#if scrollPosition> 0}
            
        <button on:click={scrollLeft} class="carousel-button carousel-button-left">
            <ChevronLeft />
        </button>
        {/if}
        {#if carouselContainer && (scrollPosition + carouselContainer.clientWidth < carouselContainer.scrollWidth) }
            
        <button on:click={scrollRight} class="carousel-button carousel-button-right">
            <ChevronRight />
        </button>
        {/if}

        <div
            bind:this={carouselContainer}
            class="carousel-container"
            on:scroll={handleScroll}
            >
            {#each items as item (item.id)}

            <div class="carousel-item">

                <Card {item}/>
            </div>
           
            {/each}
    </div>
    </div>
</div>


<style>
    .carousel-wrapper{
    position: relative;
}

.carousel-container-wrapper{
    position: relative;
}

.carousel-container{
    overflow-x: auto;
    display: flex;
    scroll-snap-type: x mandatory;
    scrollbar-width: none;
}



.carousel-container::-webkit-scrollbar {
    display: none;
}

.carousel-item {
    scroll-snap-align: center;
    flex: 0 0 auto;
    margin-right: 1rem;
}


.carousel-button{
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background-color: rgba(0, 0, 0, 0.5);
    color: white;
    border: none;
    padding: 1rem;
    cursor: pointer;
    z-index: 10;
    transition: background-color 0.3s ease;
}

.carousel-button-left{
    left: 0;
    height: 100%;
}

.carousel-button-right{
    right: 0;
    height: 100%;
}
</style>