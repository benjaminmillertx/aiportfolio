<script lang="ts">
    import { Bell, ChevronRight, Menu, Search, X } from "lucide-svelte";
    import logo from "../../public/images/Netflix-LOGO.png";
    import profileImage from "../../public/images/profile.jpg";
    import { onMount } from "svelte";
    import { goto } from "$app/navigation";

    let isSticky: boolean = false;

    let isSearchActive: boolean = false;

    let searchInputRef;

    let searchQuery: string = "";

    let isMenuOpen: boolean = false;

    const toogleSearch = (event: Event) => {
        event.stopPropagation();
        isSearchActive = !isSearchActive;
    };

    const handleSearch = async(event: KeyboardEvent) => {

        if(event.key === "Enter"){
            event.preventDefault();
            const query = searchQuery.trim()

            if(searchQuery === ""){
                return
            }


            await goto(`/search?query=${encodeURIComponent(searchQuery)}`)


            isSearchActive = false
            searchQuery = ""
        }

    };

    const handleScroll = () => {
        isSticky = window.scrollY > 50;
    };

    const toggleMenu = () => {isMenuOpen = !isMenuOpen;};

    const closeMenu = () =>{ isMenuOpen = false}

    onMount(() => {
        window.addEventListener("scroll", handleScroll);

        return () => {
            window.removeEventListener("scroll", handleScroll);
        };
    });
</script>

<header
    class={`fixed top-0 left-0 right-0 z-50 flex flex-col px-5 md:px-10 
transition-all duration-300 text-white ease-in-out ${isSticky ? "bg-black shadow-lg" : "bg-gradient-to-b from-[rgba(0,0,0,0.7)] to-transparent"}
`}
>
    <div class="flex justify-between items-center">
        <div class="flex gap-x-6 md:gap-x-8 items-center">
            <a href="/">
                <img src={logo} alt="NETFLIX LOGO" class="w-28" />
            </a>

            <nav class="hidden text-sm md:flex space-x-4">
                <a href="/" class="hover:text-gray-300">Home</a>
                <a href="/" class="hover:text-gray-300">TV Shows</a>
                <a href="/" class="hover:text-gray-300">Movies</a>
                <a href="/" class="hover:text-gray-300">New & Popular</a>
                <a href="/myList" class="hover:text-gray-300">My List</a>
                <a href="/" class="hover:text-gray-300">Browse By Languages</a>
            </nav>
        </div>

        <div class="flex items-center space-x-4">
            <div
                role="presentation"
                id="search-bar"
                class={`hidden md:flex search-container ${isSearchActive ? "active" : ""}`}
                on:click|stopPropagation={toogleSearch}
            >
                <button
                    class="search-button"
                    aria-label="Toggle Search"
                    on:click|stopPropagation={toogleSearch}
                >
                    <Search size={20} color="white" />
                </button>
                <input
                    bind:this={searchInputRef}
                    bind:value={searchQuery}
                    placeholder="Search"
                    aria-label="Search"
                    type="text"
                    class="search-input"
                    on:keydown={handleSearch}
                />
            </div>

            <Bell size={20} color="white" />

            <img
                src={profileImage}
                class="w-8 h-8 rounded cursor-pointer"
                alt="Profile"
            />

            <ChevronRight size={20} color="white" />

            <button
                id="ham-button"
                class="md:hidden ml-4 focus:outline-none"
                aria-label="ham-button"
                on:click={toggleMenu}
            >
                <Menu />
            </button>
        </div>
    </div>

    <div
        id="mobile-menu"
        role="presentation"
        on:click|stopPropagation
        class={`mobile-menu relative ${isMenuOpen ? "open" : ""} lg:hidden`}
    >
        <button on:click={closeMenu} class="absolute right-4">
            <X color="white" size={24} />
        </button>
        <div
            role="presentation"
            id="search-bar"
            class={`search-container ${isSearchActive ? "active" : ""}`}
            on:click|stopPropagation={toogleSearch}
        >
            <button
                class="search-button"
                aria-label="Toggle Search"
                on:click|stopPropagation={toogleSearch}
            >
                <Search size={20} color="white" />
            </button>
            <input
                bind:this={searchInputRef}
                bind:value={searchQuery}
                placeholder="Search"
                aria-label="Search"
                type="text"
                class="search-input"
                on:keydown={handleSearch}
            />
        </div>

        <a href="/" class="hover:text-gray-300">Home</a>
        <a href="/" class="hover:text-gray-300">TV Shows</a>
        <a href="/" class="hover:text-gray-300">Movies</a>
        <a href="/" class="hover:text-gray-300">New & Popular</a>
        <a href="/" class="hover:text-gray-300">My List</a>
        <a href="/" class="hover:text-gray-300">Browse By Languages</a>
    </div>

    {#if isMenuOpen}
    <div role="presentation" class="overlay show" on:click={closeMenu}></div>
    {/if}
</header>

<style>
    .search-container {
        position: relative;

        align-items: center;
        transition:
            width 0.3s ease-in-out,
            background-color 0.3s ease-in-out;
        overflow: hidden;
        width: 40px;
    }

    .search-container.active {
        width: 200px;
        border: 1px solid white;
        background-color: black;
    }

    .search-input {
        padding-left: 2rem;
        flex: 1;
        padding-block: 0.5rem;
        background: transparent;
        border: none;
        outline: none;
        opacity: 0;
        color: white;
        transition: opacity 0.3s ease-in-out;
    }

    .search-container.active .search-input {
        opacity: 1;
    }

    .search-button {
        position: absolute;
        padding: 0.5rem;
        cursor: pointer;
        display: flex;
        justify-items: center;
        align-items: center;
    }

    .search-button:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }


    .mobile-menu{
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background-color: #000;
        padding: 1rem 2rem;
        transition: transfrom 0.3s ease-in-out;
        transform: translateY(-100%);
        z-index: 60;
    }

    .mobile-menu.open{
        transform: translateY(0);
    }
    .mobile-menu a{
        display: block;
        padding: 0.5rem 0;
        color: white;
        text-decoration: none;
        font-size: 1.1rem;
    }

    .overlay{
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease-in-out,
        visibility 0.3s ease-in-out;
        z-index: 55;
    }

    .overlay.show{
        opacity: 1;
        visibility: visible;
    }
</style>
