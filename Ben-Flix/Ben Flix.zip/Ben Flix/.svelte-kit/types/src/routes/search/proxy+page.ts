// @ts-nocheck
import { searchMovies } from "$lib/api/API";
import type { PageLoad } from "./$types";

export const load = async({fetch,url}: Parameters<PageLoad>[0])=>{


    const response = await searchMovies(fetch,url.searchParams.get("query")!,1)


    return {
        results: response,
        query:url.searchParams.get("query")
    }


}